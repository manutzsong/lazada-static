import React from 'react';
import {Line} from 'react-chartjs-2';


export default ({dataPoints, inventory, dataOrderItems, setFinance}) => {



  if (dataPoints && dataOrderItems) {
    let priceArray = [];
    let shippingFeeArray =[];
    let labels = [];
    let shippingFeeExceedArray = [];
    let profitArray = [];
    let costArray = [];

    dataPoints.forEach(x=> {
      labels.push(new Date(x["created_at"]));
      priceArray.push(x["price"].replace(",",""));
      shippingFeeArray.push(parseFloat(x["shipping_fee"]) );
      shippingFeeExceedArray.push( parseFloat(x["shipping_fee"]) - 45 );
  
  
  
  
      //profit
      let matchedOrder = dataOrderItems.find(order => order["order_id"] === x["order_id"]);
      let matchedInventory = null;
      if(matchedOrder) {
        // console.log(matchedOrder.order_items);
        try {
          let profit = 0;
          let cost = 0;
          matchedOrder.order_items.forEach(each => {
            matchedInventory = inventory.find(inv => inv["ShopSku"] === each["shop_sku"]);
            let profitInner =  (parseFloat(each["item_price"]) - (parseFloat(each["item_price"])* 0.0214) ) - parseFloat(matchedInventory.cost);
            cost+=parseFloat(matchedInventory.cost);
            // if (parseFloat(each["shipping_amount"]) > 45) {
            //   let shippingPrice = parseFloat(each["shipping_amount"]) - 45;
            //   profitInner += shippingPrice;
            // }
  
            profit+=profitInner
            
          });
  
          profit-=parseFloat(x["voucher_seller"]);
  
          costArray.push(cost);
          profitArray.push(profit);
        }
        catch(err) {
          try {
            let profit = 0;
            let cost = 0;
            matchedOrder.order_items.forEach(each => {
              let inventoryErr = require("./inventory.json");
              let matchedInventory = inventoryErr.find(inv => inv["Shop SKU"] === each["shop_sku"]);
              let profitInner =  (parseFloat(each["item_price"]) - (parseFloat(each["item_price"])* 0.0214) ) - parseFloat(matchedInventory.cost);
              cost+=parseFloat(matchedInventory.cost);
              // if (parseFloat(each["shipping_amount"]) > 45) {
              //   let shippingPrice = parseFloat(each["shipping_amount"]) - 45;
              //   profitInner += shippingPrice;
              // }
    
              profit+=profitInner
              
            });
    
            profit-=parseFloat(x["voucher_seller"]);
    
            costArray.push(cost);
            profitArray.push(profit);
          }
          catch(err2) {
            //redirect to success screen
          }
        }
      }

    });


    const data = {
      
      labels: labels,
      datasets: [{
        label: 'Price',
        data: priceArray,
        borderColor: '#2196f3',
        fill: false
      }, {
        label: 'Shipping Fee',
        data: shippingFeeArray,
        borderColor: '#9c27b0',
        fill: false
      }, {
        label: 'Shipping Exceed',
        data: shippingFeeExceedArray,
        borderColor: '#009688',
        fill: false
      }, {
        label: 'Profit',
        data: profitArray,
        borderColor: '#4caf50',
        fill: false
      }, {
        label: 'Cost',
        data: costArray,
        borderColor: '#ff9800',
        fill: false
      }]
    };
  
    const options = {
      tooltips: {
         mode: 'index',
         intersect: false
      },
      hover: {
         mode: 'index',
         intersect: false
      },
      bezierCurve : false,
      elements: {
          line: {
              tension: 0
          }
      },
      scales: {
        xAxes: [{
          type: 'time',
          time: {
            tooltipFormat: 'LLL',
            displayFormats: {
                millisecond: 'HH:mm:ss.SSS',
                second: 'HH:mm:ss',
                minute: 'HH:mm',
                hour: 'MMM D h:mm',
                'day': 'MMM D h:mm',
                'week': 'MMM D h:mm',
                'month': 'MMM D h:mm',
                'quarter': 'MMM D h:mm',
                'year': 'MMM D YYYY h:mm',
            }
          }
      }]                 
    }
   }

   
   let financeVar = {
    profit : profitArray.reduce((a, b) => parseFloat(a) +  parseFloat(b), 0),
    price : priceArray.reduce((a, b) => parseFloat(a) +  parseFloat(b), 0),
    shippingFee : shippingFeeArray.reduce((a, b) => parseFloat(a) +  parseFloat(b), 0),
    shippingFeeExceed : shippingFeeExceedArray.reduce((a, b) => parseFloat(a) +  parseFloat(b), 0)
  };
//  setFinance(financeVar);

   return (
        <Line data={data} options={options} />
    );

  }

  else {
     return <div>NO</div>
   }
    
}