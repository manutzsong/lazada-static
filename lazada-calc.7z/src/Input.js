import React from 'react';

export default ({dataPoints, inventory, dataOrderItems}) => {
  return <div>hello</div>

}