import React from "react";

import axios from "axios";
import moment from "moment-timezone";

import "date-fns";
import CircularProgress from "@material-ui/core/CircularProgress";
import retryInterceptor from 'axios-retry-interceptor';
import "../App.css";



// const urlAPI = "http://lazada-song-ws.herokuapp.com";
const urlAPI = "http://localhost:5000";


export default class App extends React.Component {
  constructor(props) {
    super(props);
    this.state = {

      startDateUserSelect : moment("2019-11-01T00:00:00+07:00").startOf("day"),
      endDateUserSelect : moment("2019-11-25T00:00:00+07:00").endOf("day"),
      statusOrder : "delivered",
      inventory : [],
      saveOrders : [],
      saveOrderItems : [],
      saveFinanceOrder : [],

      isLoading: false,
      accessToken: sessionStorage.getItem("accesstoken")
    };
  }
  componentDidMount() {
    
    //this.dataDelivered();
    console.log(this.state.accessToken);
    this.loopPromises();
  }

  //MESSY

  loopOrderForItems = () => {
    // console.log(saveOrderItems[0], saveFinanceOrder[0]);
    //financial stats
    let orderCount = this.state.saveOrders.length;
    let itemSold = 0;

    let arrayOfOrder = [];

    //financial stats
    //https://open.lazada.com/doc/api.htm?spm=a2o9m.11193494.0.0.34e9266bqdgTeJ#/api?cid=9&path=/finance/transaction/detail/get pull this shit

    this.state.saveOrders.forEach(y => {
      //loop order
      let orderItemsMatched = this.state.saveOrderItems.find(z => z.order_id === y.order_id); //match order with order item
      let totalPaidToSeller = 0;
      let totalProfitToSeller = 0;
      let totalProduct = [];
      let totalPromotionFlexi = 0;
      let totalPromotionVoucher = 0;
      let totalBeforeDeduct = 0;
      let totalFeeName = 0;
      let totalShippingByCust = 0;
      let totalShippingCharge = 0;

      orderItemsMatched.order_items.forEach(c => {
        //loop order item (matched)
        itemSold += 1; //add item sold count

        let matchedTransaction = this.state.saveFinanceOrder.filter(
          d =>
            d["order_no"] === c["order_id"].toString() &&
            d["lazada_sku"] === c["shop_sku"]
        );
        let costOfItem = this.state.inventory.find(h => h["lazada_sku"] === c["shop_sku"]);
        let shippingFeePaidByCustomer = 0;
        let paymentFee = 0;
        let itemPriceCredit = 0;
        let promotionalFlexi = 0;
        let promotionalVoucher = 0;
        let shippingFeeChargedByLAZ = 0;
        matchedTransaction.forEach(x => {
          if (x.fee_name === "Shipping Fee (Paid By Customer)") {
            shippingFeePaidByCustomer = Number(x.amount);
          } else if (x.fee_name === "Payment Fee") {
            paymentFee = Number(x.amount);
          } else if (x.fee_name === "Item Price Credit") {
            itemPriceCredit = Number(x.amount);
          } else if (x.fee_name === "Promotional Charges Flexi-Combo") {
            promotionalFlexi = Number(x.amount);
          } else if (x.fee_name === "Shipping Fee (Charged by Lazada)") {
            shippingFeeChargedByLAZ = Number(x.amount);
          } else if (x.fee_name === "Promotional Charges Vouchers") {
            promotionalVoucher = Number(x.amount);
          } else {
            // console(x.fee_name);
          }
        });
        let paidToSeller =
          shippingFeePaidByCustomer +
          paymentFee +
          itemPriceCredit +
          promotionalFlexi +
          promotionalVoucher +
          shippingFeeChargedByLAZ;
        if (costOfItem) {
          // console.log(paidToSeller, c["order_id"], costOfItem.product.cost);
          let profitToSeller =
            paidToSeller -
            (costOfItem.product.cost ? costOfItem.product.cost : 0);

          totalPaidToSeller += paidToSeller;
          totalProfitToSeller += profitToSeller;
          totalBeforeDeduct += itemPriceCredit;
          totalFeeName += paymentFee;
          totalShippingByCust += shippingFeePaidByCustomer;
          totalShippingCharge += shippingFeeChargedByLAZ;
        } else {
          // console.log(c["order_id"]);
        }
        //do JSON

        totalProduct.push(c);
        console.log(c);
      }); //end c

      let sendThisJSON = {
        totalPaidToSeller: totalPaidToSeller,
        totalProfitToSeller: totalProfitToSeller,
        totalPromotionFlexi: totalPromotionFlexi,
        totalPromotionVoucher: totalPromotionVoucher,
        totalBeforeDeduct: totalBeforeDeduct,
        totalFeeName: totalFeeName,
        totalShippingByCust: totalShippingByCust,
        totalShippingCharge: totalShippingCharge
      };

      arrayOfOrder.push(sendThisJSON);
    });

    console.log(arrayOfOrder);
  };

  solveGetOrderItemsPromises = promises => {
    Promise.all(promises).then(async response => {
      let orders = response.map(x => x.data.data);
      let _orders = Array.prototype.concat(...orders);

      this.setState({saveOrderItems : _orders});
      this.loopOrderForItems();
    });
  };

  loopPromises = async () => {
    let inventory = await axios.get("https://lazada-node-server.herokuapp.com/");
    await this.setState({inventory : inventory.data});

    let axiosPromises = [];
    let axiosFinancePromises = [];

    let startAxios = axios.post(`${urlAPI}/getorders`, {
      shipstatus: this.state.statusOrder,
      startdate: moment(this.state.startDateUserSelect).startOf('day').format(),
      enddate: moment(this.state.startDateUserSelect).endOf('day').format(),
      accesstoken: this.state.accessToken
    });

    let startFinanceAxios = axios.post(`${urlAPI}/gettransactions`, {
      startdate: moment(this.state.startDateUserSelect).startOf('day').format(),
      enddate: moment(this.state.startDateUserSelect).endOf('day').format(),
      accesstoken: this.state.accessToken
    });

    axiosPromises.push(startAxios);
    axiosFinancePromises.push(startFinanceAxios);

    let dayDiffer = moment(this.state.endDateUserSelect).diff(
      moment(this.state.startDateUserSelect),
      "days"
    );
    console.log(dayDiffer);

    for (let i = 1; i <= dayDiffer; i++) {
      let startDate = moment(this.state.startDateUserSelect).add(i,"days").startOf('day').format();
      let endDate = moment(this.state.startDateUserSelect).add(i,"days").endOf('day').format();
      

      const data = axios.post(`${urlAPI}/getorders`, {
        shipstatus: this.state.statusOrder,
        startdate: startDate,
        enddate: endDate,
        accesstoken: this.state.accessToken
      });

      const financePromise = axios.post(`${urlAPI}/gettransactions`, {
        startdate: startDate,
        enddate: endDate,
        accesstoken: this.state.accessTokent
      },{ retry: 5, retryDelay: 1000 });

      // const financePromise = axios({
      //   url: `${urlAPI}/gettransactions`,
      //   method: 'post',
      //   data: {
      //     startdate: startDate,
      //     enddate: endDate,
      //     accesstoken: this.state.accessTokent
      //   },
      //   retry:5,
      //   retryDelay: 1000
      // });

      axiosPromises.push(data);
      axiosFinancePromises.push(financePromise);
    }

    const promiseResultOfBoth = await Promise.all(
      [axiosPromises, axiosFinancePromises].map(innerPromise => {
        return Promise.all(innerPromise);
      })
    );

    let financeResult = promiseResultOfBoth[1].map(x => x.data.data);
    let _financeResult = Array.prototype.concat(...financeResult);
    // console.log(_financeResult.length);
    

    let orders = promiseResultOfBoth[0].map(x => x.data.data.orders);
    let _orders = Array.prototype.concat(...orders);

    this.setState({saveOrders : _orders, saveFinanceOrder : _financeResult});

    let orderIDs = _orders.map(x => x.order_id.toString());
    // orderIDs = JSON.stringify(orderIDs);
    let getOrderItemsPromises = [];
    let getOrderItemsString = [];

    for (let i = 0; i < orderIDs.length; i++) {
      if (i !== 0 && i % 100 === 0) {
        getOrderItemsString.push(orderIDs[i]);
        getOrderItemsString = JSON.stringify(getOrderItemsString);

        // console.log(getOrderItems, getOrderItemsString);

        let promiseThis = axios.post(`http://localhost:5000/getorderitems`, {
          orders: getOrderItemsString,
          accesstoken: this.state.accessToken
        });
        getOrderItemsPromises.push(promiseThis);

        getOrderItemsString = [];
      } else {
        getOrderItemsString.push(orderIDs[i]);
      }
    }

    getOrderItemsString = JSON.stringify(getOrderItemsString);
    let promiseThis = axios.post(`http://localhost:5000/getorderitems`, {
      orders: getOrderItemsString,
      accesstoken: this.state.accessToken
    });

    getOrderItemsPromises.push(promiseThis);

    this.solveGetOrderItemsPromises(getOrderItemsPromises);
    // console.log(getOrderItemsPromises);
  };

  //MESSY

  handleInputChange = event => {
    console.log(event);
    const target = event.target;
    const value = target.type === "checkbox" ? target.checked : target.value;
    const name = target.name;

    console.log(value);

    this.setState({
      [name]: value
    });
  };

  handleStartDate = e => {
    let value = moment(e)
      .startOf("day")
      .format();
    this.setState({ startDate: value });
    console.log(value);
  };
  handleEndDate = e => {
    let value = moment(e)
      .endOf("day")
      .format();
    this.setState({ endDate: value });
    console.log(value);
  };

  render() {
    if (this.state.isLoading) {
      return (
        <div className="container d-flex vh-100 justify-content-center">
          <div className="align-self-center align-items-center d-flex">
            <div>
              <CircularProgress />
            </div>
            <div className="px-3">
              <h4>{this.state.isLoading}</h4>
            </div>
          </div>
        </div>
      );
    }
    return <div>x</div>;
  }
}
