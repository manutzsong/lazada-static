import React from 'react';

import axios from 'axios';
import queryString from 'query-string';
import Button from '@material-ui/core/Button';

import ReactDataGrid from "react-data-grid";
import CircularProgress from '@material-ui/core/CircularProgress';
import Divider from '@material-ui/core/Divider';

export default class App extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            code : "",
            testProduct : require('../test_products.json'),
            products:[],
            columns : [
              { name: 'Name', key: 'SellerSku', fronzen: true, width:300, sortDescendingFirst: true, resizable: true},
              { name: 'Normal Price', key: 'price', fronzen: true, width: 150, resizable: true},
              { name: 'Special Price On LAZ', key: 'special_price', fronzen: true, width: 150, resizable: true},
              { name: 'Cost', key: 'cost', width: 150, editable: true, resizable: true},
            ],
            accessToken : sessionStorage.getItem("accesstoken") || "",
            userId : sessionStorage.getItem("userid") || "",
            isLoading : true,
            totalDB : 0,
            totalLAZ : 0
          };
    }
    componentDidMount() {
      if (sessionStorage.getItem("accesstoken") && sessionStorage.getItem("userid")) {
        this.loopThroughProducts();
      }
      else {
        this.checkCode();
      }
    }

    checkCode = async() => {
      await this.setState({isLoading : "Checking your authorization"});
      let url = "https://lazada-song-ws.herokuapp.com/getaccess";
      
      const {code} = queryString.parse(this.props.location.search);
      console.log(code);

      url += `?code=${code}`; 
      axios.get(url).then( async(response) => {
        // console.log(response.data.);
        if (response.data && response.data.access_token) {
          console.log(response.data);
          sessionStorage.setItem('accesstoken', response.data.access_token);
          sessionStorage.setItem('userid', response.data.country_user_info[0].user_id);
          await this.setState({accessToken : response.data.access_token, userId : response.data.country_user_info.user_id});
          this.loopThroughProducts();
        }
        else {
          //fail
        }
      });
    }

    loopThroughProducts = async() => {
      await this.setState({isLoading : "Get product list"});
      let url = `https://lazada-song-ws.herokuapp.com/getproducts?accesstoken=${this.state.accessToken}`; 
      let products = await axios.get(url);
      let productsFromDB = await axios.get("https://lazada-node-server.herokuapp.com");
      //LAZ_SKU from DB
      let LAZ_SKU = [];
      let LAZ_Products = [];
      productsFromDB.data.forEach( x => {
        LAZ_Products.push(x.product);
        LAZ_SKU.push(x.lazada_sku);
      });

      

      //Mapping things out from LAZ API
      // let nameProducts =  products.data.data.products.map(x => x.attributes.name);
      let skus = products.data.data.products.map(x => x.skus);

      let pro = [];
      pro = pro.concat(...skus);

      await this.setState({totalDB : LAZ_SKU.length, totalLAZ : pro.length});

      for (let i=0;i<=pro.length;i++) {
        try {
          //remove maching with LAZ_SKU
          if (LAZ_SKU.includes(pro[i]["ShopSku"])) {
            let addThisProduct = LAZ_Products.find(z => z["ShopSku"] === pro[i]["ShopSku"]);
            pro[i] = addThisProduct;
          }
        }
        catch(err) {

        }
        
        //remove maching with LAZ_SKU

      };

      
      pro.forEach(x => {
        console.log(x);
      });
      

      pro.sort(function (a, b) {
        return a.SellerSku.localeCompare(b.SellerSku);
      });
      
      console.log(skus,pro);
      await this.setState({products : pro, isLoading : false});
    }


    loopProductsRender = () => {
      let renderThis = this.state.products.map(x => {
        return <div>{x.SellerSku} {x.price}</div>
      });

      return <div>{renderThis}</div>;
    }

    saveInsert = () => {
      console.log(this.state.userId, sessionStorage.getItem("userid"));
      this.setState({isLoading : "Saving your progress"});
      axios({
        method: 'post',
        url: 'https://lazada-node-server.herokuapp.com/insert',
        data: { products : JSON.stringify(this.state.products), userid : this.state.userId }
      }).then( res => {
        // this.props.history.push('/app');
        window.location.replace("https://lazada-react-client.herokuapp.com/");
      });
      
    }

    onGridRowsUpdated = ({ fromRow, toRow, updated }) => {
      this.setState(state => {
        const rows = state.products.slice();
        for (let i = fromRow; i <= toRow; i++) {
          rows[i] = { ...rows[i], ...updated };
        }
        return {products : rows };
      });
    };

    
    

    render() {
      if (this.state.isLoading) {
        return <div className="container d-flex vh-100 justify-content-center">
          <div className="align-self-center align-items-center d-flex">
            <div>
              <CircularProgress />
            </div>
            <div className="px-3">
              <h4>{this.state.isLoading}</h4>
            </div>
          </div>
        </div>
      }
        return (<div className="">
          <div className="d-flex align-items-center justify-content-center p-5 flex-column">
            <Button className="py-3" variant="contained" color="primary" onClick={() => this.saveInsert()}>
              Save , Proceed
            </Button>

            <Divider />
            <div className="pt-3">
                <p className="text-warning bg-dark">Edit cost if you want, else proceed.</p>
              <Divider />
                <h6>Total Products : {this.state.totalLAZ}</h6>
                <h6>Newly added products : {this.state.totalDB}</h6>
            </div>
            
          </div>
          <div className="container">
            <ReactDataGrid
              columns={this.state.columns}
              rowGetter={i => this.state.products[i]}
              rowsCount={this.state.products.length+1}
              onGridRowsUpdated={this.onGridRowsUpdated}
              enableCellSelect={true}
              minHeight={600}
            />
            
          </div>
      </div>);
    }
}
